# Add project specific ProGuard rules here.
-keep class id.co.bimaindogarda.patrolibig.** { *; }
