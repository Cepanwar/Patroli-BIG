package id.co.bimaindogarda.patrolibig;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Patroli B.I.G - native Android shell.
 *
 * The UI itself is the same camera/GPS/watermark web app used for the PWA,
 * but it now runs inside a real WebView hosted by a real Activity, with
 * native Android permission dialogs and a native bridge that writes photos
 * straight into MediaStore (Pictures/PatroliBIG) - a real gallery save,
 * not a browser download.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "PatroliBIG";
    private static final int REQ_RUNTIME_PERMISSIONS = 100;

    private WebView webView;
    private PermissionRequest pendingWebPermissionRequest;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        configureWebView();
        requestStartupPermissions();

        // Serve app/src/main/assets/public/* as https://appassets.androidplatform.net/assets/...
        // This is required so getUserMedia()/Geolocation are treated as a secure origin by the WebView.
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (hasPermission(Manifest.permission.CAMERA)) {
                        request.grant(request.getResources());
                    } else {
                        pendingWebPermissionRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.CAMERA}, REQ_RUNTIME_PERMISSIONS);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoCallback = callback;
                    pendingGeoOrigin = origin;
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_RUNTIME_PERMISSIONS);
                }
            }
        });

        webView.addJavascriptInterface(new WebAppInterface(), "Android");

        webView.loadUrl("https://appassets.androidplatform.net/assets/public/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private boolean hasPermission(String permission) {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStartupPermissions() {
        java.util.List<String> needed = new java.util.ArrayList<>();
        if (!hasPermission(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA);
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && !hasPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQ_RUNTIME_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Resolve whatever the WebView was waiting on when the system dialog appeared.
        if (pendingWebPermissionRequest != null) {
            if (hasPermission(Manifest.permission.CAMERA)) {
                pendingWebPermissionRequest.grant(pendingWebPermissionRequest.getResources());
            } else {
                pendingWebPermissionRequest.deny();
            }
            pendingWebPermissionRequest = null;
        }
        if (pendingGeoCallback != null) {
            pendingGeoCallback.invoke(pendingGeoOrigin, hasPermission(Manifest.permission.ACCESS_FINE_LOCATION), false);
            pendingGeoCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /**
     * JS bridge exposed to the web app as `window.Android`.
     * index.html calls Android.saveImage(base64Jpeg, fileName) instead of
     * a browser download when it detects it's running inside this app.
     */
    private class WebAppInterface {

        @JavascriptInterface
        public void saveImage(final String base64Jpeg, final String fileName) {
            boolean ok = false;
            try {
                byte[] bytes = Base64.decode(base64Jpeg, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ok = saveViaMediaStore(bytes, fileName);
                } else {
                    ok = saveLegacy(bytes, fileName);
                }
            } catch (Exception e) {
                Log.e(TAG, "saveImage failed", e);
                ok = false;
            }
            final boolean result = ok;
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this,
                        result ? "Tersimpan di Galeri > Pictures/PatroliBIG" : "Gagal menyimpan foto",
                        Toast.LENGTH_SHORT).show();
                webView.evaluateJavascript(
                        "window.onNativeSaveResult && window.onNativeSaveResult(" + result + ")", null);
            });
        }

        @JavascriptInterface
        public boolean isNativeApp() {
            return true;
        }
    }

    private boolean saveViaMediaStore(byte[] bytes, String fileName) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PatroliBIG");
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) return false;
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) return false;
            out.write(bytes);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "MediaStore save failed", e);
            return false;
        }
    }

    private boolean saveLegacy(byte[] bytes, String fileName) {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES), "PatroliBIG");
            if (!dir.exists() && !dir.mkdirs()) return false;
            File file = new File(dir, fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(bytes);
            }
            android.media.MediaScannerConnection.scanFile(
                    this, new String[]{file.getAbsolutePath()}, new String[]{"image/jpeg"}, null);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Legacy save failed", e);
            return false;
        }
    }
}
