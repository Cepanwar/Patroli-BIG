# Patroli B.I.G — Proyek Android Native

Ini **bukan PWA lagi** — ini proyek Android asli (Java + Gradle) yang membungkus
kamera/GPS/watermark dalam `WebView` nyata di dalam `Activity` Android. Hasil
build-nya adalah **file .apk** yang bisa diinstal seperti aplikasi Play Store
biasa, dengan dialog izin Kamera/Lokasi asli dari sistem Android, dan foto
tersimpan langsung ke **Galeri > Pictures/PatroliBIG** lewat MediaStore (bukan
trik download browser).

Saya tidak bisa meng-compile APK ini di sandbox saya sendiri (tidak ada Android
SDK / internet di sini), jadi proyeknya saya serahkan lengkap siap-build. Ada
**2 cara** mendapatkan file .apk yang bisa diunduh — pilih salah satu:

---

## Cara 1 — Paling mudah: build otomatis lewat GitHub Actions (tanpa install apa pun)

1. Upload folder ini ke repository GitHub baru (drag-drop semua isinya, atau `git push`).
2. Buka tab **Actions** di repo tsb → workflow **"Build Patroli B.I.G APK"** akan
   otomatis jalan (atau klik **Run workflow** manual).
3. Tunggu ± 3–5 menit sampai selesai (centang hijau).
4. Buka hasil run tsb → bagian **Artifacts** → unduh **`PatroliBIG-debug-apk`** (file .zip berisi `app-debug.apk`).
5. Ekstrak, pindahkan `app-debug.apk` ke HP Android (lewat kabel USB, Google Drive, WhatsApp ke diri sendiri, dll).
6. Di HP, buka file `.apk` tsb → izinkan "Instal dari sumber tidak dikenal" jika diminta → **Instal**.
7. Buka app "Patroli B.I.G" dari home screen → izinkan Kamera & Lokasi saat diminta.

Ini menghasilkan APK **sungguhan** yang bisa diunduh, tanpa perlu Android Studio.

---

## Cara 2 — Build manual lewat Android Studio (kalau mau ubah-ubah kode)

1. Install [Android Studio](https://developer.android.com/studio) (gratis).
2. `File > Open` → pilih folder proyek ini (`PatroliBIG-native/`).
3. Biarkan Android Studio sinkronisasi Gradle (butuh internet, sekali saja untuk unduh dependency).
4. Sambungkan HP Android via USB (aktifkan *USB debugging* di Pengaturan Developer), atau pakai emulator.
5. Klik tombol ▶ **Run** — app langsung terpasang & terbuka di HP.
6. Untuk file `.apk` yang bisa dibagikan/diunduh: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   File jadi ada di `app/build/outputs/apk/debug/app-debug.apk`.

---

## Struktur proyek

```
PatroliBIG-native/
├── build.gradle, settings.gradle, gradle.properties   ← konfigurasi Gradle
├── app/
│   ├── build.gradle                                   ← dependency & versi SDK
│   ├── src/main/
│   │   ├── AndroidManifest.xml                         ← izin Kamera, GPS, Simpan
│   │   ├── java/.../MainActivity.java                  ← jembatan native (kamera, GPS, simpan galeri)
│   │   ├── assets/public/index.html + logo.png          ← aplikasi (kamera, watermark, UI)
│   │   └── res/                                         ← ikon app & tema warna navy/emas
└── .github/workflows/build-apk.yml                     ← build APK otomatis di cloud
```

## Yang berbeda dari versi PWA sebelumnya

- Berjalan di `Activity` + `WebView` Android asli, bukan tab browser.
- Dialog izin Kamera & Lokasi memakai **dialog sistem Android native**
  (`ActivityCompat.requestPermissions`), bukan popup browser.
- Tombol "Simpan ke Galeri" memanggil jembatan `window.Android.saveImage(...)`
  yang ditulis di `MainActivity.java`, menulis file JPEG langsung ke
  `MediaStore.Images` folder `Pictures/PatroliBIG` — muncul seketika di app
  Galeri/Foto HP, tanpa lewat folder Download & tanpa share-sheet.
- Ikon app (di home screen & app drawer) sudah pakai logo B.I.G.

## Catatan versi Android

- `minSdk 24` (Android 7.0) ke atas.
- Sudah menangani perbedaan cara simpan file antara Android lama (≤9, pakai
  `WRITE_EXTERNAL_STORAGE`) dan Android modern (≥10, pakai MediaStore scoped
  storage) — otomatis pilih sesuai versi HP.

## Kalau ingin publish ke Play Store nanti

APK dari langkah di atas adalah versi **debug** (untuk instal & tes langsung).
Untuk publish ke Play Store, perlu di-*sign* dengan keystore rilis sendiri
(`Build > Generate Signed Bundle / APK` di Android Studio) — beri tahu saya
kalau mau saya bantu siapkan langkah itu juga.
